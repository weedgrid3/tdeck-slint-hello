// Copyright © SixtyFPS GmbH <info@slint.dev>
// SPDX-License-Identifier: GPL-3.0-only OR LicenseRef-Slint-Royalty-free-2.0 OR LicenseRef-Slint-Software-3.0

// cSpell:ignore itemvtable
#pragma once

#include "private/slint_internal.h"
#include "private/slint_platform_internal.h"
#include "private/slint_qt_internal.h"
#include "private/slint_window.h"
#include "private/slint_models.h"
#include "private/slint_item_tree.h"
#include "private/slint_keys.h"
#include "private/slint_data_transfer.h"

#include <vector>
#include <chrono>
#include <span>
#include <concepts>
#include <limits>

#ifndef SLINT_FEATURE_FREESTANDING
#    include <mutex>
#    include <condition_variable>
#    include <cstdint>
#    include <memory>
#endif

/// The `slint` namespace is the primary entry point into the Slint C++ API.
/// All available types are in this namespace.
///
/// See the Overview documentation for the C++ integration and how
/// to load `.slint` designs.
namespace slint {

namespace private_api {

/// Saturating float-to-int cast matching Rust's `as i32` (NaN maps to 0).
inline int saturating_float_to_int(double value)
{
    if (value != value) // NaN
        return 0;
    if (value >= std::numeric_limits<int>::max())
        return std::numeric_limits<int>::max();
    if (value <= std::numeric_limits<int>::min())
        return std::numeric_limits<int>::min();
    return static_cast<int>(value);
}

/// Convert a slint `{height: length, width: length, x: length, y: length}` to a Rect
inline cbindgen_private::Rect convert_anonymous_rect(std::tuple<float, float, float, float> tuple)
{
    // alphabetical order
    auto [h, w, x, y] = tuple;
    return cbindgen_private::Rect { .x = x, .y = y, .width = w, .height = h };
}

inline void dealloc(const ItemTreeVTable *vtable, uint8_t *ptr,
                    [[maybe_unused]] vtable::Layout layout)
{
    vtable::dealloc(vtable, ptr, layout);
}

template<typename T>
inline vtable::Layout drop_in_place(ItemTreeRef item_tree)
{
    return vtable::drop_in_place<ItemTreeVTable, T>(item_tree);
}

#if !defined(DOXYGEN)
#    if defined(_WIN32) || defined(_WIN64)
// On Windows cross-dll data relocations are not supported:
//     https://docs.microsoft.com/en-us/cpp/c-language/rules-and-limitations-for-dllimport-dllexport?view=msvc-160
// so we have a relocation to a function that returns the address we seek. That
// relocation will be resolved to the locally linked stub library, the implementation of
// which will be patched.
#        define SLINT_GET_ITEM_VTABLE(VTableName) slint::private_api::slint_get_##VTableName()
#    else
#        define SLINT_GET_ITEM_VTABLE(VTableName) (&slint::private_api::VTableName)
#    endif
#endif // !defined(DOXYGEN)

inline std::optional<cbindgen_private::ItemRc>
upgrade_item_weak(const cbindgen_private::ItemWeak &item_weak)
{
    if (auto item_tree_strong = item_weak.item_tree.lock()) {
        return { { *item_tree_strong, item_weak.index } };
    } else {
        return std::nullopt;
    }
}

inline void debug(const SharedString &str)
{
    cbindgen_private::slint_debug(&str);
}

} // namespace private_api

namespace cbindgen_private {
inline LayoutInfo LayoutInfo::merge(const LayoutInfo &other) const
{
    // Note: This "logic" is duplicated from LayoutInfo::merge in layout.rs.
    return LayoutInfo { std::min(max, other.max),
                        std::min(max_percent, other.max_percent),
                        std::max(min, other.min),
                        std::max(min_percent, other.min_percent),
                        std::max(preferred, other.preferred),
                        std::min(stretch, other.stretch) };
}
inline bool operator==(const EasingCurve &a, const EasingCurve &b)
{
    if (a.tag != b.tag) {
        return false;
    } else if (a.tag == EasingCurve::Tag::CubicBezier) {
        return std::equal(a.cubic_bezier._0, a.cubic_bezier._0 + 4, b.cubic_bezier._0);
    }
    return true;
}
}

namespace private_api {

inline static void register_item_tree(const vtable::VRc<ItemTreeVTable> *c,
                                      const std::optional<slint::Window> &maybe_window)
{
    const cbindgen_private::WindowAdapterRcOpaque *window_ptr =
            maybe_window.has_value() ? &maybe_window->window_handle().handle() : nullptr;
    cbindgen_private::slint_register_item_tree(c, window_ptr);
}

inline SharedVector<float> solve_box_layout(const cbindgen_private::BoxLayoutData &data,
                                            cbindgen_private::Slice<int> repeater_indices)
{
    SharedVector<float> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::slint_solve_box_layout(&data, ri, &result);
    return result;
}

inline SharedVector<float> solve_box_layout_ortho(const cbindgen_private::BoxLayoutOrthoData &data,
                                                  cbindgen_private::Slice<int> repeater_indices)
{
    SharedVector<float> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::slint_solve_box_layout_ortho(&data, ri, &result);
    return result;
}

inline SharedVector<uint16_t>
organize_grid_layout(cbindgen_private::Slice<cbindgen_private::GridLayoutInputData> input_data,
                     cbindgen_private::Slice<int> repeater_indices,
                     cbindgen_private::Slice<int> repeater_steps)
{
    SharedVector<uint16_t> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::Slice<uint32_t> rs =
            make_slice(reinterpret_cast<uint32_t *>(repeater_steps.ptr), repeater_steps.len);
    cbindgen_private::slint_organize_grid_layout(input_data, ri, rs, &result);
    return result;
}

inline SharedVector<uint16_t> organize_dialog_button_layout(
        cbindgen_private::Slice<cbindgen_private::GridLayoutInputData> input_data,
        cbindgen_private::Slice<DialogButtonRole> dialog_button_roles)
{
    SharedVector<uint16_t> result;
    cbindgen_private::slint_organize_dialog_button_layout(input_data, dialog_button_roles, &result);
    return result;
}

inline SharedVector<float>
solve_grid_layout(const cbindgen_private::GridLayoutData &data,
                  cbindgen_private::Slice<cbindgen_private::LayoutItemInfo> constraints,
                  cbindgen_private::Orientation orientation,
                  cbindgen_private::Slice<int> repeater_indices,
                  cbindgen_private::Slice<int> repeater_steps)
{
    SharedVector<float> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::Slice<uint32_t> rs =
            make_slice(reinterpret_cast<uint32_t *>(repeater_steps.ptr), repeater_steps.len);
    cbindgen_private::slint_solve_grid_layout(&data, constraints, orientation, ri, rs, &result);
    return result;
}

inline cbindgen_private::LayoutInfo
grid_layout_info(const cbindgen_private::GridLayoutOrganizedData &organized_data,
                 cbindgen_private::Slice<cbindgen_private::LayoutItemInfo> constraints,
                 cbindgen_private::Slice<int> repeater_indices,
                 cbindgen_private::Slice<int> repeater_steps, float spacing,
                 const cbindgen_private::Padding &padding,
                 cbindgen_private::Orientation orientation)
{
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::Slice<uint32_t> rs =
            make_slice(reinterpret_cast<uint32_t *>(repeater_steps.ptr), repeater_steps.len);
    return cbindgen_private::slint_grid_layout_info(&organized_data, constraints, ri, rs, spacing,
                                                    &padding, orientation);
}

inline cbindgen_private::LayoutInfo
box_layout_info(cbindgen_private::Slice<cbindgen_private::LayoutItemInfo> cells, float spacing,
                const cbindgen_private::Padding &padding,
                cbindgen_private::LayoutAlignment alignment)
{
    return cbindgen_private::slint_box_layout_info(cells, spacing, &padding, alignment);
}

inline cbindgen_private::LayoutInfo
box_layout_info_ortho(cbindgen_private::Slice<cbindgen_private::LayoutItemInfo> cells,
                      const cbindgen_private::Padding &padding)
{
    return cbindgen_private::slint_box_layout_info_ortho(cells, &padding);
}

inline SharedVector<float> solve_flexbox_layout(const cbindgen_private::FlexboxLayoutData &data,
                                                cbindgen_private::Slice<int> repeater_indices)
{
    SharedVector<float> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    cbindgen_private::slint_solve_flexbox_layout(&data, ri, &result, nullptr, nullptr);
    return result;
}

// Like `solve_flexbox_layout`, but with a measure callback used for
// height-for-width: `measure(index, known_w, known_h)` returns `{width,
// height}`; an absent optional means "compute it". A negative value over the C
// ABI denotes an absent dimension.
template<typename MeasureFn>
inline SharedVector<float>
solve_flexbox_layout_with_measure(const cbindgen_private::FlexboxLayoutData &data,
                                  cbindgen_private::Slice<int> repeater_indices, MeasureFn measure)
{
    SharedVector<float> result;
    cbindgen_private::Slice<uint32_t> ri =
            make_slice(reinterpret_cast<uint32_t *>(repeater_indices.ptr), repeater_indices.len);
    auto thunk = [](void *user_data, uintptr_t child_index, float known_width, float known_height,
                    float *out_width, float *out_height) {
        auto *f = reinterpret_cast<MeasureFn *>(user_data);
        auto wh = (*f)(
                child_index,
                known_width < 0 ? std::optional<float> {} : std::optional<float> { known_width },
                known_height < 0 ? std::optional<float> {} : std::optional<float> { known_height });
        *out_width = wh.first;
        *out_height = wh.second;
    };
    cbindgen_private::slint_solve_flexbox_layout(&data, ri, &result,
                                                 reinterpret_cast<const void *>(+thunk),
                                                 reinterpret_cast<void *>(&measure));
    return result;
}

inline cbindgen_private::LayoutInfo flexbox_layout_info_main_axis(
        cbindgen_private::Slice<cbindgen_private::FlexboxLayoutItemInfo> cells, float spacing,
        const cbindgen_private::Padding &padding, cbindgen_private::FlexboxLayoutWrap flex_wrap)
{
    return cbindgen_private::slint_flexbox_layout_info_main_axis(cells, spacing, &padding,
                                                                 flex_wrap);
}

inline float flexbox_layout_unwrapped_main(
        cbindgen_private::Slice<cbindgen_private::FlexboxLayoutItemInfo> cells, float spacing,
        const cbindgen_private::Padding &padding)
{
    return cbindgen_private::slint_flexbox_layout_unwrapped_main(cells, spacing, &padding);
}

inline cbindgen_private::LayoutInfo flexbox_layout_info_cross_axis(
        cbindgen_private::Slice<cbindgen_private::FlexboxLayoutItemInfo> cells_h,
        cbindgen_private::Slice<cbindgen_private::FlexboxLayoutItemInfo> cells_v, float spacing_h,
        float spacing_v, const cbindgen_private::Padding &padding_h,
        const cbindgen_private::Padding &padding_v,
        cbindgen_private::FlexboxLayoutDirection direction,
        cbindgen_private::FlexboxLayoutWrap flex_wrap, float constraint_size)
{
    return cbindgen_private::slint_flexbox_layout_info_cross_axis(
            cells_h, cells_v, spacing_h, spacing_v, &padding_h, &padding_v, direction, flex_wrap,
            constraint_size);
}

/// Access the layout cache of an item within a repeater (standard cache)
template<typename T>
inline T layout_cache_access(const SharedVector<T> &cache, int offset, int repeater_index,
                             int entries_per_item)
{
    size_t idx = size_t(cache[offset]) + repeater_index * entries_per_item;
    return idx < cache.size() ? cache[idx] : 0;
}

/// Access the layout cache of an item within a grid repeater (two-level indirection cache)
/// Formula: cache[cache[jump_index] + repeater_index * stride + child_offset]
template<typename T>
inline T layout_cache_grid_repeater_access(const SharedVector<T> &cache, size_t jump_index,
                                           size_t repeater_index, size_t stride,
                                           size_t child_offset)
{
    size_t base = jump_index < cache.size() ? size_t(cache[jump_index]) : 0;
    size_t data_idx = base + repeater_index * stride + child_offset;
    return data_idx < cache.size() ? cache[data_idx] : 0;
}

template<typename VT, typename ItemType>
inline cbindgen_private::LayoutInfo
item_layout_info(VT *itemvtable, ItemType *item_ptr, cbindgen_private::Orientation orientation,
                 float cross_axis_constraint, WindowAdapterRc *window_adapter,
                 const ItemTreeRc &component_rc, uint32_t item_index)
{
    cbindgen_private::ItemRc item_rc { component_rc, item_index };
    return itemvtable->layout_info({ itemvtable, item_ptr }, orientation, cross_axis_constraint,
                                   window_adapter, &item_rc);
}
} // namespace private_api

namespace private_api {

template<typename T>
union MaybeUninitialized {
    T value;
    ~MaybeUninitialized() { }
    MaybeUninitialized() { }
    T take()
    {
        T result = std::move(value);
        value.~T();
        return result;
    }
};

inline vtable::VRc<cbindgen_private::MenuVTable>
create_menu_wrapper(const ItemTreeRc &menu_item_tree,
                    bool (*condition)(const ItemTreeRc *menu_tree) = nullptr,
                    bool (*visible)(const ItemTreeRc *menu_tree) = nullptr)
{
    MaybeUninitialized<vtable::VRc<cbindgen_private::MenuVTable>> maybe;
    cbindgen_private::slint_menus_create_wrapper(&menu_item_tree, &maybe.value, condition, visible);
    return maybe.take();
}

inline void setup_popup_menu_from_menu_item_tree(
        const vtable::VRc<cbindgen_private::MenuVTable> &shared,
        Property<std::shared_ptr<Model<cbindgen_private::MenuEntry>>> &entries,
        Callback<std::shared_ptr<Model<cbindgen_private::MenuEntry>>(cbindgen_private::MenuEntry)>
                &sub_menu,
        Callback<void(cbindgen_private::MenuEntry)> &activated)
{
    using cbindgen_private::MenuEntry;
    entries.set_binding([shared] {
        SharedVector<MenuEntry> entries_sv;
        shared.vtable()->sub_menu(shared.borrow(), nullptr, &entries_sv);
        std::vector<MenuEntry> entries_vec(entries_sv.begin(), entries_sv.end());
        return std::make_shared<VectorModel<MenuEntry>>(std::move(entries_vec));
    });
    sub_menu.set_handler([shared](const auto &entry) {
        SharedVector<MenuEntry> entries_sv;
        shared.vtable()->sub_menu(shared.borrow(), &entry, &entries_sv);
        std::vector<MenuEntry> entries_vec(entries_sv.begin(), entries_sv.end());
        return std::make_shared<VectorModel<MenuEntry>>(std::move(entries_vec));
    });
    activated.set_handler(
            [shared](const auto &entry) { shared.vtable()->activate(shared.borrow(), &entry); });
}

inline SharedString translate(const SharedString &original, const SharedString &context,
                              const SharedString &domain,
                              cbindgen_private::Slice<SharedString> arguments, int n,
                              const SharedString &plural)
{
    SharedString result = original;
    cbindgen_private::slint_translate(&result, &context, &domain, arguments, n, &plural);
    return result;
}

inline SharedString decimal_separator()
{
    SharedString out;
    cbindgen_private::slint_decimal_separator(&out);
    return out;
}

inline StyledText parse_markdown(const SharedString &format_string,
                                 cbindgen_private::Slice<StyledText> args)
{
    StyledText result;
    cbindgen_private::slint_parse_markdown(&format_string, args, &result);
    return result;
}

inline StyledText string_to_styled_text(const SharedString &text)
{
    StyledText result;
    cbindgen_private::slint_string_to_styled_text(&text, &result);
    return result;
}

inline StyledText color_to_styled_text(const Color &color)
{
    StyledText result;
    cbindgen_private::slint_color_to_styled_text(&color, &result);
    return result;
}

inline bool open_url(const SharedString &url, const WindowAdapterRc &window_adapter)
{
    return cbindgen_private::slint_open_url(&url, &window_adapter.handle());
}

inline void macos_bring_all_windows_to_front()
{
    cbindgen_private::slint_macos_bring_all_windows_to_front();
}

inline SharedString translate_from_bundle(std::span<const char8_t *const> strs,
                                          cbindgen_private::Slice<SharedString> arguments)
{
    SharedString result;
    cbindgen_private::slint_translate_from_bundle(
            make_slice((reinterpret_cast<char const *const *>(strs.data())), strs.size()),
            arguments, &result);
    return result;
}
inline SharedString
translate_from_bundle_with_plural(std::span<const char8_t *const> strs,
                                  std::span<const uint32_t> indices,
                                  std::span<uintptr_t (*const)(int32_t)> plural_rules,
                                  cbindgen_private::Slice<SharedString> arguments, int n)
{
    SharedString result;
    cbindgen_private::Slice<const char *> strs_slice =
            make_slice(reinterpret_cast<char const *const *>(strs.data()), strs.size());
    cbindgen_private::Slice<uint32_t> indices_slice =
            make_slice(reinterpret_cast<const uint32_t *>(indices.data()), indices.size());
    cbindgen_private::Slice<uintptr_t (*)(int32_t)> plural_rules_slice =
            make_slice(reinterpret_cast<uintptr_t (*const *)(int32_t)>(plural_rules.data()),
                       plural_rules.size());
    cbindgen_private::slint_translate_from_bundle_with_plural(
            strs_slice, indices_slice, plural_rules_slice, arguments, n, &result);
    return result;
}

template<typename Component>
inline float get_resolved_default_font_size(const Component &component)
{
    ItemTreeRc item_tree_rc = (*component.self_weak.lock()).into_dyn();
    return slint::cbindgen_private::slint_windowrc_resolved_default_font_size(&item_tree_rc);
}

} // namespace private_api

// Translator API is currently considered experimental due to discussions
// about the returned string type (SharedString vs. Cow<str> etc.). Also it
// is not available with no_std due to the tr crate.
// See discussion in https://github.com/slint-ui/slint/pull/10979.
#if defined(SLINT_FEATURE_EXPERIMENTAL) && !defined(SLINT_FEATURE_FREESTANDING)
/// Interface for an external translator.
struct Translator
{
    /// Destroys the translator.
    virtual ~Translator() { }
    /// Translate a singular string. Arguments are passed as UTF-8 strings.
    /// Slint will call this method from the thread which runs the event loop.
    virtual SharedString translate(std::string_view string, std::string_view context) const = 0;
    /// Translate a plural string. Arguments are passed as UTF-8 strings.
    /// Slint will call this method from the thread which runs the event loop.
    virtual SharedString ntranslate(uint64_t n, std::string_view singular, std::string_view plural,
                                    std::string_view context) const = 0;
};

namespace private_api {

/// Helper to dispatch calls from the Rust translator to the C++ translator.
struct TranslatorDispatcher
{
    static void drop(const void *obj) { delete cast(obj); }

    static void translate(const void *obj, private_api::Slice<uint8_t> string,
                          private_api::Slice<uint8_t> context, slint::SharedString *out)
    {
        *out = cast(obj)->translate(private_api::slice_to_string_view(string),
                                    private_api::slice_to_string_view(context));
    }

    static void ntranslate(const void *obj, uint64_t n, private_api::Slice<uint8_t> singular,
                           private_api::Slice<uint8_t> plural, private_api::Slice<uint8_t> context,
                           slint::SharedString *out)
    {
        *out = cast(obj)->ntranslate(n, private_api::slice_to_string_view(singular),
                                     private_api::slice_to_string_view(plural),
                                     private_api::slice_to_string_view(context));
    }

private:
    static const Translator *cast(const void *obj) { return static_cast<const Translator *>(obj); }
};

} // namespace private_api

/// Register a custom translator.
///
/// Allows using a custom translation framework by implementing the
/// `slint::Translator` interface. Passing `nullptr` will unregister any
/// previously registered translator.
///
/// Returns `true` on success, `false` if no platform is available.
///
/// Safety & Ownership:
/// * The ownership of the translator object is passed to Slint. It will be
///   destroyed automatically when the program quits or when
///   `set_external_translator()` is called the next time.
/// * The methods on the translator object will be called from the thread
///   which the Slint event loop is running.
///
/// The function is only available when Slint is compiled with
/// `SLINT_FEATURE_EXPERIMENTAL` and without `SLINT_FEATURE_FREESTANDING`.
///
/// Note that this function has no effect if the `.slint` file was compiled
/// with bundled translations.
///
/// Example:
/// \code
///     struct MyTranslator : public slint::Translator {
///       slint::SharedString translate(std::string_view string,
///                                     std::string_view context) const override {
///         return slint::SharedString("Singular String");
///       }
///
///       slint::SharedString ntranslate(uint64_t n,
///                                      std::string_view singular,
///                                      std::string_view plural,
///                                      std::string_view context) const override {
///         return slint::SharedString("Plural String");
///       }
///     };
///
///     slint::set_external_translator(std::make_unique<MyTranslator>());
/// \endcode
inline bool set_translator(std::unique_ptr<Translator> obj)
{
    const bool success = cbindgen_private::slint_translate_set_translator(
            obj.get(), &private_api::TranslatorDispatcher::drop,
            &private_api::TranslatorDispatcher::translate,
            &private_api::TranslatorDispatcher::ntranslate);
    if (success) {
        obj.release(); // Ownership is moved to Rust.
    }
    return success;
}
#endif

/// Forces all the strings that are translated with `@tr(...)` to be re-evaluated.
/// Call this function after changing the language at run-time and when translating
/// with either gettext or a custom translator. For bundled translations, there is no need
/// to call this function.
///
/// Example (assuming usage of gettext):
/// ```cpp
///     my_ui->global<LanguageSettings>().on_french_selected([] {
///        setenv("LANGUAGE", langs[l], true);
///        slint::update_all_translations();
///    });
/// ```
inline void update_all_translations()
{
    cbindgen_private::slint_translations_mark_dirty();
}

/// Select the current translation language when using bundled translations.
/// This function requires that the application's `.slint` file was compiled with bundled
/// translations. It must be called after creating the first component.
///
/// The language string is the locale, which matches the name of the folder that contains the
/// `LC_MESSAGES` folder. An empty string or `"en"` will select the default language.
///
/// Returns true if the language was selected; false if the language was not found in the list of
/// bundled translations.
inline bool select_bundled_translation(std::string_view language)
{
    return cbindgen_private::slint_translate_select_bundled_translation(
            slint::private_api::string_to_slice(language));
}

#if !defined(DOXYGEN)
cbindgen_private::Flickable::Flickable()
{
    slint_flickable_data_init(&data);
}
cbindgen_private::Flickable::~Flickable()
{
    slint_flickable_data_free(&data);
}

cbindgen_private::SystemTrayIcon::SystemTrayIcon()
{
    slint_system_tray_icon_data_init(&data);
}
cbindgen_private::SystemTrayIcon::~SystemTrayIcon()
{
    slint_system_tray_icon_data_free(&data);
}

cbindgen_private::FocusScope::FocusScope()
{
    slint_maybe_key_binding_list_init(&key_bindings);
}
cbindgen_private::FocusScope::~FocusScope()
{
    slint_maybe_key_binding_list_free(&key_bindings);
}

cbindgen_private::NativeStyleMetrics::NativeStyleMetrics(void *)
{
    slint_native_style_metrics_init(this);
}

cbindgen_private::NativeStyleMetrics::~NativeStyleMetrics()
{
    slint_native_style_metrics_deinit(this);
}

cbindgen_private::NativePalette::NativePalette(void *)
{
    slint_native_palette_init(this);
}

cbindgen_private::NativePalette::~NativePalette()
{
    slint_native_palette_deinit(this);
}
#endif // !defined(DOXYGEN)

namespace private_api {
// Was used in Slint <= 1.1.0 to have an error message in case of mismatch
template<int Major, int Minor, int Patch>
struct [[deprecated]] VersionCheckHelper
{
};
}

/// Enum for the event loop mode parameter of the slint::run_event_loop() function.
/// It is used to determine when the event loop quits.
enum class EventLoopMode {
    /// The event loop quits when the last window is closed and the last
    /// visible system tray icon is hidden, or when slint::quit_event_loop()
    /// is called. A visible SystemTrayIcon keeps the loop alive on its own.
    QuitOnLastWindowClosed,

    /// The event loop keeps running until slint::quit_event_loop() is
    /// called, even when no windows or system tray icons are visible.
    RunUntilQuit
};

/// Enters the main event loop. This is necessary in order to receive
/// events from the windowing system in order to render to the screen
/// and react to user input.
///
/// The mode parameter determines when the loop returns. The default,
/// QuitOnLastWindowClosed, returns once the last window is closed and the
/// last visible system tray icon is hidden.
inline void run_event_loop(EventLoopMode mode = EventLoopMode::QuitOnLastWindowClosed)
{
    private_api::assert_main_thread();
    cbindgen_private::slint_run_event_loop(mode == EventLoopMode::QuitOnLastWindowClosed);
}

/// Schedules the main event loop for termination. This function is meant
/// to be called from callbacks triggered by the UI. After calling the function,
/// it will return immediately and once control is passed back to the event loop,
/// the initial call to slint::run_event_loop() will return.
inline void quit_event_loop()
{
    cbindgen_private::slint_quit_event_loop();
}

/// Adds the specified functor to an internal queue, notifies the event loop to wake up.
/// Once woken up, any queued up functors will be invoked.
/// This function is thread-safe and can be called from any thread, including the one
/// running the event loop. The provided functors will only be invoked from the thread
/// that started the event loop.
///
/// You can use this to set properties or use any other Slint APIs from other threads,
/// by collecting the code in a functor and queuing it up for invocation within the event loop.
///
/// The following example assumes that a status message received from a network thread is
/// shown in the UI:
///
/// ```
/// #include "my_application_ui.h"
/// #include <thread>
///
/// int main(int argc, char **argv)
/// {
///     auto ui = NetworkStatusUI::create();
///     ui->set_status_label("Pending");
///
///     slint::ComponentWeakHandle<NetworkStatusUI> weak_ui_handle(ui);
///     std::thread network_thread([=]{
///         std::string message = read_message_blocking_from_network();
///         slint::invoke_from_event_loop([&]() {
///             if (auto ui = weak_ui_handle.lock()) {
///                 ui->set_status_label(message);
///             }
///         });
///     });
///     ...
///     ui->run();
///     ...
/// }
/// ```
///
/// See also blocking_invoke_from_event_loop() for a blocking version of this function
template<std::invocable Functor>
void invoke_from_event_loop(Functor f)
{
    cbindgen_private::slint_post_event(
            [](void *data) { (*reinterpret_cast<Functor *>(data))(); }, new Functor(std::move(f)),
            [](void *data) { delete reinterpret_cast<Functor *>(data); });
}

#if !defined(SLINT_FEATURE_FREESTANDING) || defined(DOXYGEN)

/// Blocking version of invoke_from_event_loop()
///
/// Just like invoke_from_event_loop(), this will run the specified functor from the thread running
/// the slint event loop. But it will block until the execution of the functor is finished,
/// and return that value.
///
/// This function must be called from a different thread than the thread that runs the event loop
/// otherwise it will result in a deadlock. Calling this function if the event loop is not running
/// will also block forever or until the event loop is started in another thread.
///
/// The following example is reading the message property from a thread
///
/// ```
/// #include "my_application_ui.h"
/// #include <thread>
///
/// int main(int argc, char **argv)
/// {
///     auto ui = MyApplicationUI::create();
///     ui->set_status_label("Pending");
///
///     std::thread worker_thread([ui]{
///         while (...) {
///             auto message = slint::blocking_invoke_from_event_loop([ui]() {
///                return ui->get_message();
///             }
///             do_something(message);
///             ...
///         });
///     });
///     ...
///     ui->run();
///     ...
/// }
/// ```
template<std::invocable Functor>
auto blocking_invoke_from_event_loop(Functor f) -> std::invoke_result_t<Functor>
{
    std::optional<std::invoke_result_t<Functor>> result;
    std::mutex mtx;
    std::condition_variable cv;
    invoke_from_event_loop([&] {
        auto r = f();
        std::unique_lock lock(mtx);
        result = std::move(r);
        cv.notify_one();
    });
    std::unique_lock lock(mtx);
    cv.wait(lock, [&] { return result.has_value(); });
    return std::move(*result);
}

#    if !defined(DOXYGEN) // Doxygen doesn't see this as an overload of the previous one
// clang-format off
template<std::invocable Functor>
    requires(std::is_void_v<std::invoke_result_t<Functor>>)
void blocking_invoke_from_event_loop(Functor f)
// clang-format on
{
    std::mutex mtx;
    std::condition_variable cv;
    bool ok = false;
    invoke_from_event_loop([&] {
        f();
        std::unique_lock lock(mtx);
        ok = true;
        cv.notify_one();
    });
    std::unique_lock lock(mtx);
    cv.wait(lock, [&] { return ok; });
}
#    endif
#endif

/// Sets the application id for use on Wayland or X11 with
/// [xdg](https://specifications.freedesktop.org/desktop-entry-spec/latest/) compliant window
/// managers. This must be set before the window is shown.
inline void set_xdg_app_id(std::string_view xdg_app_id)
{
    private_api::assert_main_thread();
    SharedString s = xdg_app_id;
    cbindgen_private::slint_set_xdg_app_id(&s);
}

} // namespace slint
